<?php
/**
 * Copyright © Bluethink Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Bluethinkinc_ReturnPolicy', __DIR__);
