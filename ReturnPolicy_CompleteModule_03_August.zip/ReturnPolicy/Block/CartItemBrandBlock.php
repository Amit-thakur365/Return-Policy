<?php

namespace Bluethinkinc\ReturnPolicy\Block;

use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Catalog\Api\Data\ProductInterfaceFactory;
use Magento\Catalog\Model\ProductFactory;
use Magento\Checkout\Block\Cart\Additional\Info as AdditionalBlockInfo;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\View\Element\Template as ViewTemplate;
use Magento\Framework\View\Element\Template\Context;

/**
 * Class CartItemBrandBlock
 */
class CartItemBrandBlock extends ViewTemplate
{
    /**
     * Product
     *
     * @var ProductInterface|null
     */
    protected $product = null;

    /**
     * Product Interface Factory
     *
     * @var ProductInterfaceFactory
     */
    protected $productInterfaceFactory;

    /**
     * Product Factory
     *
     * @var ProductFactory
     */
    protected $productFactory;

    /**
     * CartItemBrandBlock constructor
     *
     * @param Context $context
     * @param ProductInterfaceFactory $productInterfaceFactory
     */
    public function __construct(
        Context $context,
        ProductInterfaceFactory $productInterfaceFactory,
        ProductFactory $productFactory
    ) {
        parent::__construct($context);
        $this->productInterfaceFactory = $productInterfaceFactory;
        $this->productFactory = $productFactory;
    }

    /**
     * Get Product Return Policy Text
     *
     * @return string
     */
    public function getReturnPolicy(): string
    {
        $product = $this->getProduct();
        $_productType = $product->getTypeId();
        $sku = $product->getSku();
        if ($_productType == 'configurable') {
            $_product = $this->productFactory->create();
            $productData = $_product->loadByAttribute('sku', $sku);
            $returnPolicy = $productData->getAttributeText('return_policy');
        } else {
            $returnPolicy = $product->getResource()->getAttribute('return_policy')->getFrontend()->getValue($product);
        }
        return $returnPolicy;
    }

    /**
     * Get product from quote item
     *
     * @return ProductInterface
     */
    public function getProduct(): ProductInterface
    {
        try {
            $layout = $this->getLayout();
        } catch (LocalizedException $e) {
            $this->product = $this->productInterfaceFactory->create();
            return $this->product;
        }
        /** @var AdditionalBlockInfo $block */
        $block = $layout->getBlock('additional.product.info');
        if ($block instanceof AdditionalBlockInfo) {
            $item = $block->getItem();
            $this->product = $item->getProduct();
        }
        return $this->product;
    }
}
