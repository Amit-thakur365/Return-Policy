var config = {
    map: {
       '*': {
          'Magento_Swatches/js/swatch-renderer':'Bluethinkinc_ReturnPolicy/js/swatch-renderer'
       }
    }
};
