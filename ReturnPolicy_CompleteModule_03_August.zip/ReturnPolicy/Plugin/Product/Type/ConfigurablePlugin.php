<?php

namespace Bluethinkinc\ReturnPolicy\Plugin\Product\Type;

class ConfigurablePlugin
{
    public function afterGetUsedProductCollection(\Magento\ConfigurableProduct\Model\Product\Type\Configurable $subject, $result)
    {
        $result->addAttributeToSelect('description');
        $result->addAttributeToSelect('return_policy');
        return $result;
    }
}
