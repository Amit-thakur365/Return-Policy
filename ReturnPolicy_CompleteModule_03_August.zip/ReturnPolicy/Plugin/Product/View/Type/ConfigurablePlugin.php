<?php

namespace Bluethinkinc\ReturnPolicy\Plugin\Product\View\Type;

class ConfigurablePlugin
{
     protected $jsonEncoder;
     protected $jsonDecoder;

    public function __construct(
        \Magento\Framework\Json\DecoderInterface $jsonDecoder,
        \Magento\Framework\Json\EncoderInterface $jsonEncoder
    ) {
        $this->jsonEncoder = $jsonEncoder;
        $this->jsonDecoder = $jsonDecoder;
    }

    public function afterGetJsonConfig(\Magento\ConfigurableProduct\Block\Product\View\Type\Configurable $subject, $result)
    {
        $result = $this->jsonDecoder->decode($result);
        $currentProduct = $subject->getProduct();

        if ($currentProduct->getName()) {
            $result['productName'] = $currentProduct->getName();
        }

        if ($currentProduct->getSku()) {
            $result['productSku'] = $currentProduct->getSku();
        }

        if ($currentProduct->getDescription()) {
            $result['productDescription'] = $currentProduct->getDescription();
        }
        foreach ($subject->getAllowProducts() as $product) {
            $result['names'][$product->getId()] = $product->getName();
            $result['skus'][$product->getId()] = $product->getSku();
            $result['desc'][$product->getId()] = $product->getDescription();
            $result['returnpolicy'][$product->getId()] = $product->getResource()->getAttribute('return_policy')->getFrontend()->getValue($product);
        }
        return $this->jsonEncoder->encode($result);
    }
}
