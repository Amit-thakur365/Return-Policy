<?php

namespace Bluethinkinc\ReturnPolicy\Plugin;

use Magento\Quote\Model\Quote\Item\ToOrderItem;
use Magento\Quote\Model\Quote\Item\AbstractItem;

class QuoteItemToOrderItemPlugin
{
    public function aroundConvert(ToOrderItem $subject, \Closure $proceed, AbstractItem $item, $additional = [])
    {
        /** @var $orderItem \Magento\Sales\Model\Order\Item */
        $orderItem = $proceed($item, $additional);
        $orderItem->setReturnPolicy($item->getReturnPolicy());
        return $orderItem;
    }
}
