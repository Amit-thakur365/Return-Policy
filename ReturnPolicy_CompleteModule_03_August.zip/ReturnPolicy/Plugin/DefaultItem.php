<?php

namespace Bluethinkinc\ReturnPolicy\Plugin;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Model\ProductFactory;
use Magento\Quote\Model\Quote\Item;

class DefaultItem
{
    protected $productRepo;

    public function __construct(
        ProductRepositoryInterface $productRepository,
        ProductFactory $productFactory
    ) {
        $this->productRepo = $productRepository;
        $this->productFactory = $productFactory;
    }

    public function aroundGetItemData($subject, \Closure $proceed, Item $item)
    {
        // /** For Simple Products Only */
        // $data = $proceed($item);
        // $_product = $item->getProduct();
        // $result = [];
        // $result['return_policy'] = $_product->getResource()->getAttribute('return_policy')->getFrontend()->getValue($_product);
        // return array_merge($data,$result);

        // /** For Simple and Configurable both Products */
        $data = $proceed($item);
        $atts = [];

        $_product = $item->getProduct();
        $_productType = $_product->getTypeId();
        $sku = $_product->getSku();

        if ($_productType == 'configurable') {
            $product = $this->productFactory->create();
            $productData = $product->loadByAttribute('sku', $sku);
            $return_policy = $productData->getAttributeText('return_policy');
        } else {
            $return_policy = $_product->getResource()->getAttribute('return_policy')->getFrontend()->getValue($_product);
        }

        $atts = ["return_policy" => $return_policy];
        return array_merge($data, $atts);
    }
}
